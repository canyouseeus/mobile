import { GoogleGenAI, Type } from "@google/genai";
import { GenerateStoryResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateLostStory = async (userPrompt: string): Promise<GenerateStoryResponse> => {
  const model = "gemini-2.5-flash";
  
  const response = await ai.models.generateContent({
    model: model,
    contents: `Write a mysterious, evocative archive entry for a "lost" item based on this prompt: "${userPrompt}". 
    The item could be a physical object, a memory, or a place that no longer exists. 
    The tone should be sophisticated, slightly melancholic, or mysterious.`,
    config: {
      systemInstruction: "You are the Archivist of 'The Lost+Unfounds', a digital registry of things misplaced in time and space.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING, description: "A poetic or mysterious title for the entry" },
          itemType: { type: Type.STRING, description: "What the object essentially is (e.g. 'Silver Pocketwatch', 'Unsent Letter')" },
          dateLost: { type: Type.STRING, description: "Approximate date or era it was lost" },
          location: { type: Type.STRING, description: "Last known location" },
          shortDescription: { type: Type.STRING, description: "A one sentence hook about the item" },
          fullStory: { type: Type.STRING, description: "A paragraph (approx 100 words) describing the item and the mystery of its disappearance." },
          mood: { type: Type.STRING, enum: ['Melancholy', 'Mysterious', 'Nostalgic', 'Eerie', 'Hopeful'] }
        },
        required: ["title", "itemType", "dateLost", "location", "shortDescription", "fullStory", "mood"]
      }
    }
  });

  const text = response.text;
  if (!text) {
    throw new Error("No response from Gemini");
  }

  return JSON.parse(text) as GenerateStoryResponse;
};